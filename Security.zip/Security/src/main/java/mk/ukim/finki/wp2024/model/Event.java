package mk.ukim.finki.wp2024.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
public class Event {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String description;
    private double popularityScore;


    @ManyToOne
    private Location location;
    private int numTickets;

    public Event(String name, String description, double popularityScore,
                 Location location, int numTickets) {
        this.name = name;
        this.description = description;
        this.popularityScore = popularityScore;
        this.location = location;
        this.numTickets = numTickets;
    }
}