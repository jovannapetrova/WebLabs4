package mk.ukim.finki.wp2024.service.impl;

import jakarta.transaction.Transactional;
import mk.ukim.finki.wp2024.model.Event;
import mk.ukim.finki.wp2024.model.Location;
import mk.ukim.finki.wp2024.model.exceptions.LocationNotFoundException;
import mk.ukim.finki.wp2024.repository.jpa.EventRepository;
import mk.ukim.finki.wp2024.repository.jpa.LocationRepository;
import mk.ukim.finki.wp2024.service.EventService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class EventServiceImpl implements EventService {
    private final EventRepository eventRepository;
    private final LocationRepository locationRepository;


    public EventServiceImpl(EventRepository eventRepository, LocationRepository locationRepository) {
        this.eventRepository = eventRepository;
        this.locationRepository = locationRepository;

    }

    @Override
    public List<Event> listAll() {
        return eventRepository.findAll();
    }

    @Override
    public Optional<Event> findById(Long id) {
        return eventRepository.findById(id);
    }

    @Override
    public Optional<Event> findByName(String name) {
        return eventRepository.findByName(name);
    }


    @Override
    public List<Event> searchEvents(String text) {
        return eventRepository.findAllByNameLike(text);
    }

    @Override
    public List<Event> findByLocation(Long locationId) {
        return eventRepository.findAllByLocation_Id(locationId);
    }



    @Override
    public void save(String name, String description, double popularityScore,
                      Long locationId, int numTickets) {
        Location location = locationRepository.findById(locationId).orElseThrow(() -> new LocationNotFoundException(locationId));
        this.eventRepository.save(new Event(name, description, popularityScore, location, numTickets));
    }

    @Override
    public void deleteById(Long id) {
        eventRepository.deleteById(id);
    }

    @Override
    @Transactional
    public void reserveCard(Long eventId, int numTickets) {
        this.eventRepository.decrementNum(eventId, numTickets);
    }


}