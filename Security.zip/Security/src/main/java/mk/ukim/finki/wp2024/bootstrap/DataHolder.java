package mk.ukim.finki.wp2024.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp2024.model.*;

import mk.ukim.finki.wp2024.repository.jpa.EventRepository;
import mk.ukim.finki.wp2024.repository.jpa.LocationRepository;
import mk.ukim.finki.wp2024.repository.jpa.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import mk.ukim.finki.wp2024.model.enumerations.Role;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {
    public static List<Event> events = null;
    public static List<EventBooking> MyBookings = null;

    public static List<Location> locations = null;
    public static List<User> users = null;


    private final UserRepository userRepository;
    private final LocationRepository locationRepository;
    private final EventRepository eventRepository;
    private final PasswordEncoder passwordEncoder;

    public DataHolder( UserRepository userRepository,
                       LocationRepository locationRepository, EventRepository eventRepository,PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.locationRepository = locationRepository;
        this.eventRepository = eventRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @PostConstruct
    public void init() {


        locations = new ArrayList<>();
        if (this.locationRepository.count() == 0) {
            locations.add(new Location("Стадион на Вимблдон", "SW19, Лондон, Велика Британија", "15,000", "Познат тениски стадион, дом на Вимблдон шампионатите."));
            locations.add(new Location("Стадион Олд Трафорд", "Манчестер, Велика Британија", "74,000", "Дом на фудбалскиот клуб Манчестер Јунајтед."));
            locations.add(new Location("ICC Конгресен Центар", "Хајдарабад, Индија", "10,000", "Голем конгресен центар кој организира меѓународни настани."));
            locations.add(new Location("Конгресен Центар Лос Анџелес", "Лос Анџелес, САД", "72,000", "Популарен конгресен и изложбен простор."));
            locations.add(new Location("Медисон Сквер Гарден", "Њујорк, САД", "20,000", "Светски познат спортски и забавен објект."));
            locations.add(new Location("Лувр Музеј", "Париз, Франција", "35,000", "Најголемиот и најпосетуван музеј во светот."));
            locations.add(new Location("Москоне Центар", "Сан Франциско, САД", "80,000", "Главен конгресен центар во центарот на Сан Франциско."));
            locations.add(new Location("Токио Дом", "Токио, Јапонија", "55,000", "Иконичен стадион, дом на бейзбол тимот Јомиури Џајантс."));
            locations.add(new Location("Опера Сиднеј", "Сиднеј, Австралија", "5,000", "Светски познат центар за изведувачки уметности."));
            locations.add(new Location("Колосеум", "Рим, Италија", "50,000", "Антички римски амфитеатар и туристичка атракција."));
            this.locationRepository.saveAll(locations);
        }

        events = new ArrayList<>();
        if (this.eventRepository.count() == 0) {
            events.add(new Event("Вимблдон", "Тениски турнир", 9,locations.get(0), 50));
            events.add(new Event("ЛШ", "Фудбалски турнир", 10,  locations.get(1), 60));
            events.add(new Event("Како да станеш богат", "Конференција", 8,  locations.get(2), 50));
            events.add(new Event("Како да успееш од Македонија", "Конференција", 10,  locations.get(3), 70));
            events.add(new Event("Здраво Свете", "Отворање на подкаст", 7,  locations.get(4), 60));
            events.add(new Event("Комик Кон", "Конвенција за поп култура", 10,  locations.get(5), 40));
            events.add(new Event("Технолошки Самит", "Технолошка конференција", 9, locations.get(6), 60));
            events.add(new Event("Џез Фестивал", "Музички фестивал", 7,  locations.get(7), 30));
            events.add(new Event("Изложба на уметност", "Изложба на уметност", 8,  locations.get(8), 50));
            events.add(new Event("Фестивал за здравје и добробит", "На настан за свест за здравје", 6,  locations.get(9), 40));
            this.eventRepository.saveAll(events);
        }
        users = new ArrayList<>();
        if (this.userRepository.count() == 0) {
            users.add(new User("jovana.petrova", passwordEncoder.encode("jp"), "Јована", "Петрова", Role.ROLE_USER));
            users.add(new User("andrea.balveva", passwordEncoder.encode( "andrea"), "Андреа", "Балевска",Role.ROLE_USER));
            users.add(new User("martin.begov", passwordEncoder.encode( "mb"), "Мартин", "Бегов",Role.ROLE_USER));
            users.add(new User("josif.agov", passwordEncoder.encode("jag"), "Јосиф", "Агов",Role.ROLE_USER));
            users.add(new User("admin",passwordEncoder.encode("admin"),"admin","admin",Role.ROLE_ADMIN));
            this.userRepository.saveAll(users);
        }


        //PRIMER
        //@PreAuthorize("hasRole('ROLE_ADMIN')")
        //public void someAdminOnlyMethod() {
        //    // Оваа функција е достапна само за администратори
        //}
    }

}