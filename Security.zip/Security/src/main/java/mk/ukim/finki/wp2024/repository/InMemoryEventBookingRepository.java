package mk.ukim.finki.wp2024.repository;

import mk.ukim.finki.wp2024.bootstrap.DataHolder;
import mk.ukim.finki.wp2024.model.EventBooking;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class InMemoryEventBookingRepository {
    public InMemoryEventBookingRepository() {
    }

    public void addBooking(EventBooking booking) {
        DataHolder.MyBookings.add(booking);
    }

    public List<EventBooking> listMyBookings() {
        return DataHolder.MyBookings.stream().toList();
    }

    public List<EventBooking> searchEvents(String text) {
        return DataHolder.MyBookings.stream().filter(e -> e.getEventName().contains(text)).toList();
    }
}