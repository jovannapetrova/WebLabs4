package mk.ukim.finki.wp2024;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Wp2024ApplicationTests {

    @Test
    void contextLoads() {
    }

}
